from .human_controller import HumanController
from .controller_abc import GameController
from .auto_controller import AIController